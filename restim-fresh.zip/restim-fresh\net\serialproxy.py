import re
import numpy as np
import logging

from PySide6 import QtCore
from PySide6.QtSerialPort import QSerialPort
from PySide6.QtCore import QIODevice

from net.tcode import TCodeCommand, InvalidTCodeException
from qt_ui import settings

logger = logging.getLogger('restim.serial')


class FunscriptExpander:
    def __init__(self):
        self.alpha = 0

    def expand(self, cmd: TCodeCommand):
        if cmd.interval < 10:
            return [0], [cmd.value * 2 - 1], [0]

        alpha_start = self.alpha
        alpha_end = cmd.value * 2 - 1
        duration = cmd.interval

        center = (alpha_start + alpha_end) / 2
        radius = abs(center - alpha_start)
        n = max(2, int(duration / 10))
        interval = np.linspace(0, cmd.interval, n)
        theta = np.linspace(0, np.pi, n)
        beta = radius * np.sin(theta)
        alpha = center + radius * np.cos(theta)
        if alpha_start < alpha_end:
            beta *= -1
            alpha = center - (alpha - center)

        self.alpha = alpha_end
        return interval, alpha, beta


class SerialProxy(QtCore.QObject):
    def __init__(self, parent):
        super().__init__(parent)

        self.expander = FunscriptExpander()
        self.do_auto_expand = settings.serial_auto_expand.get()

        self.port = QSerialPort(self)
        self.port.setPortName(settings.serial_port.get())
        self.port.setBaudRate(115200)
        self.port.readyRead.connect(self.new_serial_data)
        if settings.serial_enabled.get():
            b = self.port.open(QIODevice.ReadOnly)
            if b:
                logger.info(f"Serial listener active on port: {self.port.portName()}")
            else:
                logger.error(f"Unable to listen to serial port: {self.port.errorString()}")

        self.data = b''

    def new_serial_data(self):
        self.data += bytes(self.port.readAll())
        while 1:
            match = re.search(b'[\n\r ]', self.data)
            if match is None:
                return
            cmd = self.data[0:match.regs[0][0]]
            self.data = self.data[match.regs[0][1]:]
            if len(cmd) < 3:
                continue
            try:
                tcode = TCodeCommand.parse_command(cmd)
                if self.do_auto_expand:
                    interval, alpha, beta = self.expander.expand(tcode)
                    for i, a, b in zip(interval, alpha, beta):
                        self.new_tcode_command.emit(TCodeCommand('L0', a / 2 + 0.5, i))
                        self.new_tcode_command.emit(TCodeCommand('L1', b / 2 + 0.5, i))
                else:
                    self.new_tcode_command.emit(tcode)
            except InvalidTCodeException as e:
                pass

    new_tcode_command = QtCore.Signal(TCodeCommand)
