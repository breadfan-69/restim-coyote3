import numpy as np


def norm(x, y):
    return np.linalg.norm((x, y), axis=0)

