if __name__ == '__main__':
    import sys
    from qt_ui import mainwindow
    sys.exit(mainwindow.run())
