class PulseFrequency:
    min = 1
    max = 100

class CarrierFrequency:
    min = 500
    max = 3000

class DutyCycle:
    min = 0
    max = 0.9

